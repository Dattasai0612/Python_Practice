# My Package
A simple Python package for checking if a number is a palindrome.

## Installation
```bash
pip install my_package
