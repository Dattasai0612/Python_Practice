# __init__.py
from .your_module import is_palindrome

__all__ = ["is_palindrome"]
